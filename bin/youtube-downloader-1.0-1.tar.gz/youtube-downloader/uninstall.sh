#!/bin/bash
rm -r /usr/local/lib/youtube-downloader
rm -r /usr/local/etc/youtube-downloader
rm -f /usr/local/share/applications/youtube-downloader.desktop
rm -f /usr/share/pixmaps/youtube-downloader.png
rm -f /usr/local/bin/youtube-downloader